class Converter:
    def __init__(self, value, bits):
        self.value = value
        self.bits = bits
        self.binary_str = ""

def convert(number):
    c = number.value
    n = number.bits
    
    # Split into integer and fractional parts
    integer_part = int(c)
    fractional_part = c - integer_part
    
    # Convert integer part
    s_integer = ""
    if integer_part == 0:
        s_integer = "0"
    while integer_part > 0:
        remainder = integer_part % 2
        s_integer = str(remainder) + s_integer
        integer_part = integer_part // 2
        
    # Convert fractional part
    s_fraction = ""
    temp_fraction = fractional_part
    counter = 0
    while counter < n:
        temp_fraction = temp_fraction * 2
        if temp_fraction >= 1:
            s_fraction = s_fraction + "1"
            temp_fraction = temp_fraction - 1
        else:
            s_fraction = s_fraction + "0"
        counter = counter + 1
        
    result_bin = s_integer + "." + s_fraction
    number.binary_str = result_bin
    
    # Convert back to decimal
    before_dot = s_integer
    after_dot = s_fraction
    
    back_to_decimal = 0

    # Integer part back
    index = 0
    for i in range(len(before_dot)-1, -1, -1):
        if before_dot[i] == "1":
            back_to_decimal = back_to_decimal + (2 ** index)
        index = index + 1
        
    # Fractional part back
    index_after = 1
    for char in after_dot:
        if char == "1":
            back_to_decimal = back_to_decimal + (1 / (2 ** index_after))
        index_after = index_after + 1
        
    print("Binary:", result_bin)
    print("Back:", back_to_decimal)
    print("Difference:", c - back_to_decimal)

try:
    input_c = input("Enter a number: ")
    if input_c == "":
        c = 64.256
        print(f"No number entered. Using {c}")
    else:
        c = float(input_c)
        
    input_b = input("Bits: ")
    if input_b == "":
        b = 8
        print(f"No bits entered. Using {b}")
    else:
        b = int(input_b)

    if c < 0 or b < 0 or b > 15:
        print("Error: Number and bits must be positive and bits max 15!!")
    else:
        converter_obj = Converter(c, b)
        convert(converter_obj)
except:
    print("ERROR")
class text_data:
    def __init__(self, input_text):
        self.original = input_text

        # Allowed characters
        allowed_characters = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789áéíóúůýščřžďťňäëöüěÁÉÍÓÚŮÝŠČŘŽĎŤŇÄËÖÜĚ .?!,;"
        
        # Removing unsupported characters
        self.cleaned = ""
        for char in self.original:
            if char in allowed_characters:
                self.cleaned += char

def analyze_text(text_obj):
    text = text_obj.cleaned
    
    # Total character count
    character_count = len(text)
    
    # Characters without spaces 
    character_count_without_spaces = 0
    for char in text:
        if char != " ":
            character_count_without_spaces += 1
            
    # Word count (number of spaces)
    word_count = 0
    in_word = False
    for char in text:
        if char != " ":
            if not in_word: # In case there were 2 or more spaces together
                word_count += 1
                in_word = True
        else:
            in_word = False
            
    # Sentence count (number of punctuation marks)
    sentence_count = 0
    for char in text:
        if char in ".?!":
            sentence_count += 1

    # Results
    print("Text to analyze:", text)
    print("Total characters:", character_count)
    print("Characters without spaces:", character_count_without_spaces)
    print("Words:", word_count)
    print("Sentences:", sentence_count)

if __name__ == "__main__":
    user_input = input("Enter your text (or leave empty): ").strip()
    
    if user_input == "":
        user_input = "Příliš žluťoučký kůň úpěl ďábelské ódy. Je to 123 @ test?"
        print("Using default test sentence.")

    try:
        data = text_data(user_input)
        analyze_text(data)
    except Exception as e:
        print("Error: Something went wrong with the input.")
        print(e)